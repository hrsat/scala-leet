Nurun
=====

#### L37'5 h4v3 50m3 fun.

If you've never heard of leet speak then shame on you! A once respected dialect on the interwebs is now used for fun by
n00b and l337 alike. There are no hard rules on how to write it, but we'll keep it simple by replacing certain letters
with the mapping below:

* [a,A] -> 4
* [e,E] -> 3
* [i,I] -> 1
* [o,O] -> 0
* [s,S] -> 5
* [t,T] -> 7

Note: `[o,O]` is not an owl face, it's the letter "o" and it should be replaced with a zero.

### Objective

Use the apply method `com.nurun.scala.Leet` object to convert a String into l337.

### Examples

1. Let's have some fun. -> L37'5 h4v3 50m3 fun.
2. C is for cookie, that's good enough for me -> C 15 f0r c00k13, 7h47'5 g00d 3n0ugh f0r m3
3. By the power of Grayskull! -> By 7h3 p0w3r 0f Gr4y5kull!

### Testing

For example we'll be trying to run the object using `scala com.nurun.scala.leet.Main "You are elite!"`